-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 28, 2022 at 08:20 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_gwd`
--

-- --------------------------------------------------------

--
-- Table structure for table `destinasi`
--

CREATE TABLE `destinasi` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userlog` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `destinasi`
--

INSERT INTO `destinasi` (`id`, `image`, `title`, `deskripsi`, `userlog`, `created_at`, `updated_at`) VALUES
(5, '0327202212554762405ed381119dest_gwd.jpg', 'GWD', '<div>Grand Watudodol</div>', 'admingwd1', '2022-03-27 05:55:47', '2022-03-27 05:55:47'),
(6, '0327202212583562405f7b37b0ddest_apung.jpg', 'Rumah Apung', '<div>Rumah Apung</div>', 'admingwd1', '2022-03-27 05:58:35', '2022-03-27 05:58:35'),
(7, '0327202212590062405f94dbc15dest_tabuhan.jpg', 'Pulau Tabuhan', '<div>Pulau Tabuhan</div>', 'admingwd1', '2022-03-27 05:59:00', '2022-03-27 05:59:00'),
(8, '0327202212592862405fb0c46fbdest_menjangan.jpg', 'Pulau Menjangan', '<div>Pulau Menjangan</div>', 'admingwd1', '2022-03-27 05:59:28', '2022-03-27 05:59:28');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `galeri`
--

CREATE TABLE `galeri` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userlog` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `galeri`
--

INSERT INTO `galeri` (`id`, `image`, `userlog`, `created_at`, `updated_at`) VALUES
(2, '03272022104820624040f47e656gal-1.jpg', 'admingwd1', '2022-03-27 03:48:20', '2022-03-27 03:48:20'),
(3, '0327202210484062404108e1a28gal-2.jpg', 'admingwd1', '2022-03-27 03:48:40', '2022-03-27 03:48:40'),
(4, '0327202210485062404112d4f14gal-3.jpg', 'admingwd1', '2022-03-27 03:48:50', '2022-03-27 03:48:50'),
(5, '032720221049016240411d69f8agal-4.jpg', 'admingwd1', '2022-03-27 03:49:01', '2022-03-27 03:49:01'),
(6, '032720221049126240412841f3cgal-5.jpg', 'admingwd1', '2022-03-27 03:49:12', '2022-03-27 03:49:12'),
(7, '03272022104923624041333631egal-6.jpg', 'admingwd1', '2022-03-27 03:49:23', '2022-03-27 03:49:23'),
(8, '032720221049356240413f97f6dgal-7.jpg', 'admingwd1', '2022-03-27 03:49:35', '2022-03-27 03:49:35'),
(9, '0327202210494562404149b1481gal-8.jpg', 'admingwd1', '2022-03-27 03:49:45', '2022-03-27 03:49:45'),
(10, '032720221049566240415455119gal-9.jpg', 'admingwd1', '2022-03-27 03:49:56', '2022-03-27 03:49:56'),
(11, '03272022105011624041635612cgal-10.jpg', 'admingwd1', '2022-03-27 03:50:11', '2022-03-27 03:50:11'),
(12, '0327202210502962404175db24bgal-11.jpg', 'admingwd1', '2022-03-27 03:50:29', '2022-03-27 03:50:29'),
(13, '032720221050436240418361c77gal-12.jpg', 'admingwd1', '2022-03-27 03:50:43', '2022-03-27 03:50:43');

-- --------------------------------------------------------

--
-- Table structure for table `kontak`
--

CREATE TABLE `kontak` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `alamat` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_wa` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ig` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fb` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `kontak`
--

INSERT INTO `kontak` (`id`, `alamat`, `no_wa`, `email`, `ig`, `fb`, `created_at`, `updated_at`) VALUES
(1, 'Grand Watudodol Jl. Raya Situbondo, Parasputih, Bangsring, Wongsorejo, Banyuwangi, Jawa Timur', '+6282334867904', 'info@grandwatudodol.com', 'https://www.instagram.com/grandwatudodol_bwi/', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_03_27_052823_destinasi', 2),
(6, '2022_03_27_085240_paket_wisata', 3),
(7, '2022_03_27_102143_galeri', 4),
(8, '2022_03_27_111558_kontak', 5);

-- --------------------------------------------------------

--
-- Table structure for table `paket`
--

CREATE TABLE `paket` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `harga` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `fasilitas` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `userlog` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `paket`
--

INSERT INTO `paket` (`id`, `image`, `title`, `harga`, `fasilitas`, `userlog`, `created_at`, `updated_at`) VALUES
(1, '03272022165017624095c974878dest_gwd.jpg', 'Paket Wisata P. Tabuhan dan P. Menjangan', '<ul><li>Sharing 300k Per Pax (Minimal 4 Orang)</li><li>Paket Private 2000k (Max 6 Orang)</li><li>Per Paket 2500k (Minimal 10 Orang)</li></ul>', '<ul><li>Transportasi Kapal Wisata PP</li><li>Surat Ijin Kawasan Konservasi</li><li>Life Vest / Pelampung</li><li>Tiket Taman Nasional</li><li>Tiket Masuk GWD</li><li>Snorkel Set</li><li>Kamera Underwater</li><li>Guide Snorkeling</li><li>Asuransi</li><li>Lunch Box + Air Mineral</li><li>* Find / Kaki Katak (Exclude)</li></ul>', 'admingwd1', '2022-03-27 02:26:00', '2022-03-27 09:50:17'),
(2, '03272022165052624095ec92dd6dive_menjangan.jpg', 'Diving Di Pulau Menjangan', '<ul><li>1200k 2x Dive (Minimal 2 Orang)</li></ul>', '<ul><li>Transportasi Kapal Wisata PP</li><li>Tiket Masuk GWD</li><li>Tiket Pulau Menjangan</li><li>Snorkel Set</li><li>Tabung Diving</li><li>Kamera Underwater</li><li>Guide Diving</li><li>Asuransi</li><li>Lunch Box + Air Mineral</li></ul>', 'admingwd1', '2022-03-27 02:50:40', '2022-03-27 09:50:52'),
(4, '03272022165239624096570367adive_gwd.jpg', 'Diving Di Wisata GWD', '<ul><li>800k 2x Dive (Minimal 2 Orang)</li></ul>', '<ul><li>Tiket Masuk GWD</li><li>Snorkel Set</li><li>Tabung Diving</li><li>Kamera Underwater</li><li>Guide Diving</li><li>Asuransi</li><li>Lunch Box + Air Mineral</li></ul>', 'admingwd1', '2022-03-27 09:52:39', '2022-03-27 09:52:39'),
(5, '03272022165355624096a356705snor_gwd.jpg', 'Snorkeling Di Wisata GWD', '<ul><li>100k Per Orang</li></ul>', '<ul><li>Tiket Masuk GWD</li><li>Life Vest / Pelampung</li><li>Snorkel Set</li><li>Kamera Underwater</li><li>Guide Snorkeling</li><li>Asuransi</li></ul>', 'admingwd1', '2022-03-27 09:53:55', '2022-03-27 09:53:55'),
(6, '03272022165448624096d8ca148fishing.jpg', 'Fishing', '<ul><li>1200k</li></ul>', '<ul><li>Kapal</li><li>Guide</li><li>Kuota Max 10 Orang</li></ul>', 'admingwd1', '2022-03-27 09:54:48', '2022-03-27 09:54:48'),
(7, '032720221655436240970f89d10educ_lobster.jpg', 'Edukasi Lobster', '<ul><li>100k Per Orang (Minimal 2 Orang)</li></ul>', '<ul><li>Tiket Masuk GWD</li><li>Kamera Underwater</li><li>Guide</li><li>Asuransi</li></ul>', 'admingwd1', '2022-03-27 09:55:43', '2022-03-27 09:55:43'),
(8, '03272022165851624097cb60ffdtransplantasi.jpg', 'Edukasi Transplantasi Terumbu Karang', '<ul><li>500k (Kuota Tidak Dibatasi)</li></ul>', '<ul><li>Media (Tempat Koral)</li><li>Koral 20</li><li>Alat Snorkeling 2 Set</li><li>Kamera Underwater</li><li>Guide</li></ul>', 'admingwd1', '2022-03-27 09:58:51', '2022-03-27 09:58:51'),
(9, '03272022165943624097ff09910kuliner_lobster.jpg', 'Kuliner Lobster', '<ul><li>150k Per Orang</li></ul>', '<ul><li>Nasi</li><li>Lobster</li><li>Sayur</li><li>Air Mineral / Teh</li></ul>', 'admingwd1', '2022-03-27 09:59:43', '2022-03-27 09:59:43'),
(10, '032720221700286240982cdc001camping.jpg', 'Camping', '<ul><li>25k Per Orang</li></ul>', '<ul><li>Tiket Masuk GWD</li><li>Camping Area</li><li>* Tenda Bawa Sendiri / Exclude</li></ul>', 'admingwd1', '2022-03-27 10:00:28', '2022-03-27 10:00:28'),
(11, '03272022170107624098539ecd9perahu.jpg', 'Lain-lain', '<ul><li>10k - 15k Per Orang</li></ul>', '<ul><li>Penyewaan ATV 15k Per Orang (3x Putaran)</li><li>Naik Perahu Tradisional 10k Per Orang</li></ul>', 'admingwd1', '2022-03-27 10:01:07', '2022-03-27 10:01:07');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin GWD', 'admingwd1', 'admin1@admin.com', NULL, '$2y$10$4dZA085xnAewFGR1dm/pZeSnwRsdEw6x5enn4pSetFNFFDgK79HK6', NULL, NULL, NULL),
(2, 'Admin GWD', 'admingwd2', 'admin2@admin.com', NULL, '$2y$10$Yu1uvy01ZVQECSW38Ne1z.pBQkCrPtgDCGxWsWuFsMIulN4tb3Gwi', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `destinasi`
--
ALTER TABLE `destinasi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `galeri`
--
ALTER TABLE `galeri`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kontak`
--
ALTER TABLE `kontak`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paket`
--
ALTER TABLE `paket`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `destinasi`
--
ALTER TABLE `destinasi`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `galeri`
--
ALTER TABLE `galeri`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `kontak`
--
ALTER TABLE `kontak`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `paket`
--
ALTER TABLE `paket`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
